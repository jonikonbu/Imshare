<template>
<div id="imageup">
<!--画像タイトルとお気に入りボタン、いいねボタン-->
<v-container>
    <v-row>
      <v-col cols="12" md="6">
        <h2>{{imgData.title}}</h2>
           <div v-if="likeShow">
            <v-btn v-show="likeShow" class="ma-2" text icon color="pink" @click="deleteLike(docId)"><v-icon>mdi-thumb-up</v-icon></v-btn>
            <v-btn v-show="!likeShow" class="ma-2" text icon color="dark" @click="addLike(docId)"><v-icon>mdi-thumb-up</v-icon></v-btn>
            {{imgData.likeCount}}
           </div>
           <div v-else>
            <v-btn v-show="!likeShow" class="ma-2" text icon color="dark" @click="addLike(docId)"><v-icon>mdi-thumb-up</v-icon></v-btn>
            <v-btn v-show="likeShow" class="ma-2" text icon color="pink" @click="deleteLike(docId)"><v-icon>mdi-thumb-up</v-icon></v-btn>
            {{imgData.likeCount}}
           </div>
            <div v-if="bookMarkShow"> 
            <v-btn v-show="bookMarkShow" class="ma-2" text icon color="pink" @click="deleteBookMark"><v-icon>mdi-star</v-icon></v-btn>
            <v-btn v-show="!bookMarkShow" class="ma-2" text icon color="dark" @click="addBookMark"><v-icon>mdi-star</v-icon></v-btn>
            {{imgData.bookMark}}
            </div>
            <div v-else> 
            <v-btn v-show="!bookMarkShow" class="ma-2" text icon color="dark" @click="addBookMark"><v-icon>mdi-star</v-icon></v-btn>
            <v-btn v-show="bookMarkShow" class="ma-2" text icon color="pink" @click="deleteBookMark"><v-icon>mdi-star</v-icon></v-btn>
            {{imgData.bookMark}}
            </div>
           
        <!--選択した画像を表示-->
      <v-card>
          <v-img :src="imgData.imgUrl" alt="img" style="width:100%; height:450px;"></v-img>
      </v-card>
      </v-col>
 
<!--コメントリスト-->
    <v-col cols="12" md="6">
    <div class="comment-list">                       
    <div class="comment-logo">
        <h4>コメント</h4>
    </div>
        <div class="comment-btn">
            <v-btn color="#1E90FF"><v-icon style="color:#fff;">mdi-plus</v-icon><span style="color:#fff; font-weight:bold;">コメントする</span></v-btn>
        </div>         
     <el-table :data="tableData">
        <el-table-column prop="date" label="日付" width="120px">
        </el-table-column>
        <el-table-column prop="comment" label="コメント">
        </el-table-column>
    </el-table> 
    </div> 
    </v-col>
  </v-row> 
</v-container>          
</div>
</template>
<script>
import {db,fb} from '../firebase'

export default {
    data() {
    //コメントデータをここで管理
    const item={
      date: '2016-05-02',
      comment: 'Tom',
    };
      return {
        //firebaseStoreで受け取ったimg情報を受け取る
        imgData:{},
        //遷移時に渡したパラメーターを受け取る
        docId:this.$route.params.post,
        //bookMarkボタンの初期値
        bookMarkShow:false,
        //likeボタンの初期値
        likeShow:false,
        //コメントの最大表示数の設定
        tableData: Array(10).fill(item)
      }
    },

    //遷移時に渡したドキュメントIDを元にfirebaseでstore取得をしてdataに情報を入れている。
   mounted(){
      console.log(this.$store.state)
      const uid = this.$store.state.userUid.uid
      console.log(uid)
      
      const imgDataRef = db.collection('posts')
      imgDataRef.where('docId', '==', this.docId).get()
        .then((querySnapshot)=>{
          querySnapshot.forEach((doc)=>{
            this.imgData = doc.data()
          })
        })
        const likeBookRef = imgDataRef.doc(this.docId)
          likeBookRef.collection('like').doc(uid)
            .get().then((doc)=>{
              console.log(doc.data())
              if(doc.data().uid == uid){
                this.likeShow = true
              }
            })
          db.collection('users').doc(uid).collection('bookMark').doc(uid)
           .get().then((doc)=>{
             if(doc.data().uid == uid){
                this.bookMarkShow = true
              }
           })    
   },
   methods:{
      addBookMark(){
        this.imgData.bookMark ++
        this.bookMarkShow = !this.bookMarkShow

          const addRef = db.collection('posts').doc(this.docId);
            addRef.update({bookMark:fb.firestore.FieldValue.increment(1)})
              db.collection('users').doc(this.$store.state.userUid.uid)
              .collection('bookMark').doc(this.$store.state.userUid.uid)
                .set({
                  title:this.imgData.title,
                  imgUrl:this.imgData.imgUrl,
                  docId:this.docId,
                  uid:this.$store.state.userUid.uid
                })
      },

      deleteBookMark(){
        this.imgData.bookMark --
        this.bookMarkShow = !this.bookMarkShow
          const deleteRef = db.collection('posts').doc(this.docId)
            deleteRef.update({bookMark:fb.firestore.FieldValue.increment(-1)})
              db.collection('users').doc(this.$store.state.userUid.uid)
                .collection('bookMark').doc(this.$store.state.userUid.uid).delete()
      },

      addLike(postId){
        this.imgData.likeCount ++
        this.likeShow = !this.likeShow
        this.$store.dispatch('addLike',postId)
        
      },
      deleteLike(postId){
        this.imgData.likeCount --
        this.likeShow = !this.likeShow
        this.$store.dispatch('deleteLike',postId)
      }
   }
    
};
</script>
<style>
.image-area v-img{
  text-align: center;
}

</style>

