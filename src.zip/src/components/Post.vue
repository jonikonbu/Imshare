<template>
<div id="post">
<v-container>
  <div>
   <v-row>
     <v-col cols="12" md="6" class="img-grid">
    <!--アップロード用の機能-->
    <my-upload
    @crop-success="cropSuccess"
    @src-file-set="srcFileSet"
    v-model="show"
		:width="300"
		:height="300"
		url=""
		langType="ja"
		img-format="png"
    imgBgc="#000080">
    </my-upload>
    <!--プレビュー-->
    <div class="imgarea">
	<img :src="imgDataUrl">
    </div>
  <v-btn class="upload-btn" color="#1E90FF" @click="toggleShow"><span style="color:#fff; font-weight:bold;">画像選択</span>
  </v-btn>
     </v-col>
    <!--タイトルやカテゴリー選択-->
      <v-col cols="12" md="6" class="post-form">
      <v-text-field v-model="title" label="タイトル"></v-text-field>
      <v-select style="margin-top:50px" class="select" v-model="category" :items="items" label="カテゴリー">
      
    </v-select>
    <br/>
      <v-btn color="#1E90FF" style="margin-top:50px; font-weight:bold;" class="save-btn" @click="addImgFirebase"><span style="color:#fff;">投稿</span></v-btn>
      </v-col>
    </v-row>
  </div>
</v-container>
</div>
</template>
<script>

import 'babel-polyfill'; // es6 shim
import myUpload from 'vue-image-crop-upload';
import {db,storage} from '../firebase';


  export default{
    components:{
      'my-upload': myUpload
    },

    data(){
      return{
        //カテゴリー選択の値
        show: false,

        category:'null',
        items:[
          '写真',
          'イラスト'
        ],
        title:'',
        

        imgDataUrl: '',
        fileName:'',
        fileType:'',
        
        

      };
    },
    methods:{
      toggleShow() {
				this.show = !this.show;
			},
      srcFileSet(fileName, fileType){
          console.log('ファイルセット');
          this.fileName = fileName;
          this.fileType = fileType;
        },
			cropSuccess(imgDataUrl){
        this.imgDataUrl = imgDataUrl;
      },
      
      addImgFirebase(){
        //ログイン中のユーザーのuidを取得
        const uid = this.$store.state.userUid.uid
        const name = this.fileName
        const imgDataUrl = this.imgDataUrl;

        //親postsコレクションに入れるデータをまとめて定義
        const imgData={
         date:new Date(),
         title:this.title,
         category:this.category,
         imgUrl:"",
         fileName:this.fileName,
         fileType:this.fileType,
         docId:"",
         likeCount:0,
         bookMark:0,
       }

       //ストレージのリファレンス
       const storageRef = storage.child(`${uid}/${name}`);
        //ストレージにbase64で画像を保管
       storageRef.putString(imgDataUrl,'data_url')
        //ストレージで保存した画像からファイルのURLを取得
       .then(()=>{
         storageRef.getDownloadURL().then((url)=>{
           //imgDataオブジェクトのimgUrlへファイルのURLを定義
            imgData.imgUrl = url


            //storeへ情報を保管

           //親のpostsにimgDataオブジェクトを保管
            db.collection('posts').add(imgData)
            //親のpostsのドキュメントIDをdocRefへ受取
            .then((docRef)=>{
              db.collection('posts').doc(docRef.id).update({docId:docRef.id})
              //usersのpostsサブコレクションのリファレンス（親のドキュメントIDと同じ）
              const userCl = db.collection('users').doc(uid).collection('posts').doc(docRef.id);
              //postsサブコレクションにデータを保管
              userCl.set({
                date:new Date(),
                //imgDataを直接入れていないため、ここでimgUrlプロパティを生成して
                //imgDataのimgUrlにアクセス
                imgUrl:imgData.imgUrl,
                title:imgData.title,
                docId:docRef.id
              })
              .then(()=>{
                alert('投稿を完了しました。')
                location.reload();
              })
            })
            .catch(function(error){
              console.log(error)
            })

          })
       })
      }
    }
  }

      
      </script>
    <style>
#post{
  position: relative;
  top:80px;
}
.img-grid{
  text-align: center;
}
.plus-btn{
 position:relative;
 top:2px;
}

.upload-btn{
  margin:60px;
}





</style>
