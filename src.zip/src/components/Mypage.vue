<template>
<div id="mypage">
  <v-container>
<div class="mypage">
    
      <!--マイページアイコン-->
    <v-row class="mypage-list">
      <v-col cols="12" md="6" style="text-align:center;">
       <h2 class="logo-icon"><v-icon style="font-size:200px; margin-top:30px;">mdi-account-circle</v-icon></h2>
      </v-col>
    <v-col cols="12" md="6" style="text-align:left;">
        <ul style="margin:10px;" class="user-list">
          <li style="margin-top:30px; font-size:20px;">Name：{{this.$store.state.user.name}}</li>
          <hr/>
          <!--変更する名前の入力-->
          <li> <v-text-field placeholder="変更したい名前を入力" v-model="userName" label="Name" required style="margin-top:10px;">Name</v-text-field></li>
        </ul>
        <div style="text-align:right; margin:20px;">
        <v-btn color="#1E90FF" class="btn" @click="userNameChange(userName)" style="margin-top:5px; font-weight:bold;"><span style="color:#fff;">名前を変更</span></v-btn>
        </div>
      <ul style="margin-top:10px; margin-left:10px;" class="user-list">
      <li style="margin-top:30px; font-size:20px;">Email：{{this.$store.state.user.email}}</li>
      <hr/>
      </ul>
      <div style="text-align:right;">
      <ul>
        <li style="margin:20px;"><v-btn color="#1E90FF"><span style="color:#fff; font-weight:bold;">Emailを変更</span></v-btn></li>
        <li style="margin:20px;"><v-btn color="#1E90FF"><span style="color:#fff; font-weight:bold;">パスワードを変更</span></v-btn></li>
      </ul>
      </div>
      
    </v-col>
    </v-row>
    
</div>
  <br/>
    <div class="management-img">
        <v-tabs color="#000080" v-model="tabs">
          <v-tab style="font-weight:bold;">投稿リスト</v-tab>
          <v-tab style="font-weight:bold;">ブックマーク</v-tab>
        </v-tabs>
          <v-container fluid>
            <v-tabs-items v-model="tabs">
              <!--投稿管理リスト-->
              <v-tab-item>
               <v-row>
                  <v-col v-for="image in postImages" :key="image.imgUrl" cols="12" md="2">
                    <v-card style="border-radius:15px;">
                    <v-img :src="image.imgUrl" class="white--text align-end img">
                    <v-card-title style="font-weight:bold; font-size:15px;" v-text="image.title"></v-card-title>
                    </v-img>
                    <v-card-actions>
                       <v-spacer></v-spacer>
                       <v-btn class="mx-2" fab dark small color="red" @click="deleteDialog = true"><v-icon color="#FFF">mdi-delete</v-icon></v-btn>
                        <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${image.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
                    </v-card-actions>
                    </v-card>
                    <!--投稿作品削除ダイアログ-->
                    <v-dialog v-model="deleteDialog" style="text-align:center;">
                      <v-card>
                        <v-card-text style="font-size:17px;">投稿作品を削除しますがよろしいですか？</v-card-text>
                          <v-divider></v-divider>
                            <v-card-actions>
                              <v-btn color="primary" @click="deleteDialog = false"><span style="color:#fff;">clear</span></v-btn>
                              <v-btn color="error" @click="deleteImg(image.docId)"><span style="color:#fff;">yes</span></v-btn>
                           </v-card-actions>
                        </v-card>
                    </v-dialog>
                 </v-col>
                 </v-row>
              </v-tab-item>
              <v-tab-item>
                <v-row>
                  <v-col v-for="bookMark in bookMarkImg" :key="bookMark.imgUrl" cols="12" md="2">
                    <v-card>
                      <v-img :src="boomMark.imgUrl"></v-img>
                      <v-card-title style="font-weight:bold; font-size:15px;" v-text="bookMark.title"></v-card-title>
                      <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${bookMark.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>
                </v-row>
              </v-tab-item>
            </v-tabs-items>
          </v-container>
       
    </div>
  </v-container>
          
</div>
  </template>
  <script>
      import {db} from '../firebase'

      export default{
        name:'Mypage',
          data(){
              return{
                //入力した項目をここの格納
                  //ユーザー情報を保管
                  userName:"",

                  //タブ情報
                  tabs:null,

                  //投稿した作品を保管
                  postImages:[],

                  //ブックマークした作品を保管
                  bookMarkImg:[],
                  
                  //削除ダイアログ
                  deleteDialog:false,
              }
          },

          mounted(){
            //vuex uidの取得
            const uid = this.$store.state.userUid.uid
        
            //投稿データを取得
            const storeRef = db.collection('users').doc(uid).collection('posts');
            storeRef.get()
            .then((querySnapshot)=>{
              querySnapshot.forEach(doc =>{
                this.postImages.push(doc.data());
              });
            })
            .catch((error) => {
            alert(error)
          })

            //ブックマークのデータを取得
           const bookRef = db.collection('users').doc(uid).collection('bookMark')
            bookRef.where('uid','==',uid).get()
             .then((querySnapshot)=>{
               querySnapshot.forEach((doc)=>{
                 this.bookMarkImg.push(doc.data());
               })
             })
            .catch((error) => {
            alert(error)
          })
          },
          methods:{
            //投稿画像の削除
            deleteImg(docId){
             const uid = this.$store.state.userUid.uid 
              db.collection('users').doc(uid)
                .collection('posts').doc(docId).delete()
                  const deleteRef = db.collection('posts').doc(docId)
                    deleteRef.collection('like').doc(uid).delete()
                     deleteRef.collection('bookMark').doc(uid).delete()
                      .then(()=>{
                        db.collection('posts').doc(docId).delete()
                      })
                      .then(()=>{
                        location.reload();
                      })
            },
            userNameChange(name){
              const uid = this.$store.state.userUid.uid
              if(name){
                db.collection('users').doc(uid).update({
                  name:name
                })
                  .then(()=>{
                    alert('名前を変更しました。')
                    location.reload();
                  })
              }else{
                alert('名前を入力して下さい')
              }
            }
      }
      }
  </script>
  <style scoped>
    #mypage{
      position: relative;
      top:50px;
    }
    ul{
      list-style: none;
    }
    
    

    



      
      
      
  </style>