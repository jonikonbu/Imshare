<template>
<div id="home">
  <v-container>
    <!--ソートメニュー-->
    <div>
    <v-tabs color="#000080" v-model="tabs">
      <v-tab><span style="font-weight:bold;">新着順</span></v-tab>
      <v-tab><span style="font-weight:bold;">人気順</span></v-tab>
      <v-tab><span style="font-weight:bold;">写真</span></v-tab>
      <v-tab><span style="font-weight:bold;">イラスト</span></v-tab>
    </v-tabs>
      <v-container fluid>
        <v-tabs-items v-model="tabs"> 
    <!--画像リスト-->
    <!--新着順-->
    <v-tab-item>
          <v-row>
            <v-col v-for="post in posts" :key="post.title" cols="12" md="3">
              <v-card style="border-radius:15px;">
              <v-img :src="post.imgUrl" class="white--text align-end img">
               <v-card-title style="font-weight:bold; font-size:15px;" v-text="post.title"></v-card-title>
              </v-img>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${post.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
              </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
    </v-tab-item>
    <!--人気順-->
    <v-tab-item>
          <v-row>
            <v-col v-for="post in posts" :key="post.title" cols="12" md="3">
              <v-card style="border-radius:15px;">
              <v-img :src="post.imgUrl" class="white--text align-end img">
               <v-card-title style="font-weight:bold; font-size:15px;" v-text="post.title"></v-card-title>
              </v-img>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${post.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
              </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
    </v-tab-item>
    <!--写真-->
    <v-tab-item>
          <v-row>
            <v-col v-for="post in posts" :key="post.title" cols="12" md="3">
              <v-card style="border-radius:15px;">
              <v-img :src="post.imgUrl" class="white--text align-end img">
               <v-card-title style="font-weight:bold; font-size:15px;" v-text="post.title"></v-card-title>
              </v-img>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${post.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
              </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
    </v-tab-item>
    <!--イラスト-->
    <v-tab-item>
          <v-row>
            <v-col v-for="post in posts" :key="post.title" cols="12" md="3">
              <v-card style="border-radius:15px;">
              <v-img :src="post.imgUrl" class="white--text align-end img">
               <v-card-title style="font-weight:bold; font-size:15px;" v-text="post.title"></v-card-title>
              </v-img>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn small color="#1E90FF"><router-link :to="{ name: 'Imageup',params:{ post:`${post.docId}` }}" style="color:#fff; font-weight:bold;">more</router-link></v-btn>
              </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
    </v-tab-item>
        </v-tabs-items>
    </v-container>
    </div>
  </v-container>
</div>
  </template>
  <script>
import {db} from '../firebase'
  export default{
    name:'Home',
    
    data(){

      return {
        tabs:null,
        posts:[],
        //新着順
        newPosts:[],
        //人気順
        popularPosts:[],
        //写真
        photoPosts:[],
        //イラスト
        illustPosts:[],
      }
    },
     mounted(){
       //新着順
        const storeRef = db.collection('posts');
          storeRef.get()
            .then((snap)=>{
                snap.forEach(doc =>{
                  this.posts.push(doc.data());
              });
            })   
          
       //人気順
       //写真
       //イラスト  
     }, 
  }
</script>
<style>
  .img:hover{
    transition: 0.5s;
    color:#fff;
    opacity:0.5;
  }

</style>
