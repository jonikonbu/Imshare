<template>
<v-app>
<div id="app">
  
  <!--ナビゲーションバー-->
    <v-app-bar flat Inverted-Scroll >
      <!--ハンバーガーアイコン-->
    <v-app-bar-nav-icon
      class="hidden-md-and-up"
      @click="drawer = true"
    />
    <!--ロゴ-->
    <v-container class="mx-auto py-0">
      <v-row align="center">
        <v-img
          :src="require('./assets/logo.jpg')"
          class="mr-5"
          contain
          height="48"
          width="48"
          max-width="48"
        />

        <!--ナビボタン-->
        <v-btn depressed class="hidden-sm-and-down" style="margin-left:20px;"><router-link to="/" style="text-decoration:none; color:#000080; font-weight:bold;">Home</router-link></v-btn>
        <v-btn depressed class="hidden-sm-and-down" style="margin-left:20px;"><router-link to="/post" style="text-decoration:none; color:#000080; font-weight:bold;">Post</router-link></v-btn>
        <v-btn depressed class="hidden-sm-and-down" style="margin-left:20px;"><router-link to="/mypage" style="text-decoration:none; color:#000080; font-weight:bold;">Mypage</router-link></v-btn>

        <!--ユーザーボタン-->
        <v-menu>
          <template v-slot:activator="{ on, attrs }">
          <v-btn depressed class="hidden-sm-and-down" v-bind="attrs" v-on="on" style="margin-left:20px; color:#000080; font-weight:bold;">
          User
          </v-btn>
          </template>
          <v-list>
            <v-list-item><v-btn color="#1E90FF" depressed class="login" @click="loginModal = true"><span style="color:#fff;">Login</span></v-btn></v-list-item>
            <v-list-item><v-btn color="#1E90FF" depressed class="signin" @click="signinModal = true"><span style="color:#fff;">Signin</span></v-btn></v-list-item>
            <v-list-item><v-btn color="#1E90FF" depressed @click="logOut"><span style="color:#fff;">Logout</span></v-btn></v-list-item>
          </v-list>
        </v-menu>

        <v-spacer />
        <!--サーチ機能-->
        <v-text-field
          color="#1E90FF"
          append-icon="mdi-magnify"
          flat
          hide-details
          solo-inverted
          style="max-width: 300px;"
        />
      </v-row>
      {{this.$store.state.login}}
    </v-container>
  </v-app-bar>
  <!--ページコンポネント-->
  <router-view class="view"/>
  
  <!--ハンバーガーメニュー ドロワー-->
  <v-navigation-drawer v-model="drawer" absolute temporary>
      <v-list nav dense>
        <v-list-item-group>

          <v-list-item>
            <v-list-item-icon>
              <v-icon color="#000080">mdi-home</v-icon>
            </v-list-item-icon>
            <v-list-item-title><router-link to="/" style="color:#000080;">Home</router-link></v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon color="#000080">mdi-image</v-icon>
            </v-list-item-icon>
            <v-list-item-title><router-link to="/post" style="color:#000080;">Post</router-link></v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon color="#000080">mdi-account</v-icon>
            </v-list-item-icon>
            <v-list-item-title><router-link to="/mypage" style="color:#000080;">Mypage</router-link></v-list-item-title>
          </v-list-item>

          <v-list-group no-action sub-group value="true"
        >
        <!--ユーザードロワー-->
          <template v-slot:activator>
            <v-list-item-content>
              <v-list-item-title style="color:#000080;">User</v-list-item-title>
            </v-list-item-content>
          </template>

          <v-list-item >
            <v-list-item-title><v-btn depressed color="#1E90FF" class="login" @click="loginModal = true"><span style="color:#fff;">Login</span></v-btn></v-list-item-title>
          </v-list-item>
          <v-list-item >
            
            <v-list-item-title><v-btn depressed color="#1E90FF" class="signin" @click="signinModal = true"><span style="color:#fff;">Signin</span></v-btn></v-list-item-title>
            
          </v-list-item>
          <v-list-item >
            <v-list-item-title><v-btn color="#1E90FF" depressed @click="logOut"><span style="color:#fff;">Logout</span></v-btn></v-list-item-title>
          </v-list-item>
        </v-list-group>

        </v-list-item-group>
      </v-list>

    </v-navigation-drawer>

    <!--新規登録モーダル-->
    <v-dialog v-model = "signinModal" max-width="600px">
      <v-card>
        <v-card-title>SignIn</v-card-title>
        <v-card-text>
          <v-text-field v-model="signInName" label="Name*" required></v-text-field>
          <v-text-field v-model="signInEmail" label="Email*" required></v-text-field>
          <v-text-field v-model="signInPassword" label="PassWord*" type="password" required></v-text-field>
        </v-card-text>
        <v-divider></v-divider>
          <v-card-actions>
          <v-btn color="error" @click="signinModal = false">Close</v-btn>
          <v-btn color="primary" @click="createUserSignIn">Registration</v-btn>
        </v-card-actions>
        
      </v-card>
    </v-dialog>
    
    <!--ログインモーダル-->
    <v-dialog v-model = "loginModal" max-width="600px">
      <v-card>
        <v-card-title>SignIn</v-card-title>
        <v-card-text>
          <v-text-field v-model="email" label="Email*" required></v-text-field>
          <v-text-field v-model="password" label="PassWord*" type="password" required></v-text-field>
        </v-card-text>
        <v-divider></v-divider>
          <v-card-actions>
          <v-btn color="error" @click="loginModal = false">Close</v-btn>
          <v-btn color="primary" @click="userLogIn">Login</v-btn>
        </v-card-actions>
        
      </v-card>
    </v-dialog>
    
</div> 
</v-app>
    </template>

    <script>
    
import {auth,db} from './firebase'

export default {
  name:'App',
  data(){
    return{
      drawer: false,
      logoutBtnShow:false,
    
      loginModal:false,
      signinModal:false,
      
      //サーチ用の空の値
    keyword:'',

    //新規登録用
    signInName:'',
    signInEmail:'',
    signInPassword:'',

    //ログイン登録用
    email:'',
    password:''
    }
  },
  computed:{
    user(){
      return this.$store.getters['user']
    },
  },
  created(){
   if (this.$store.state.login == false){
     this.$store.dispatch('autoLogin')
   }
  },
  mounted(){
    if(this.$store.state.login == true){
      this.logoutBtnShow = true
    }else{
      this.logoutBtnShow = false
    }
  },  
  methods:{
    //ログアウト処理
    logOut(){
            auth
            .signOut()
            .then(()=>{
              this.$store.dispatch('logOut')
              alert("ログアウトしました。");
              this.$router.push('/');
              })
              .catch(error=>{
                alert(error);
              });
            },
    //ログイン処理        
    userLogIn(email,password){
      console.log(email,password)
        this.$store.dispatch('login',{email:this.email,password:this.password})
        .then(()=>{
                alert("ログインしました。")
                this.loginModal= false
        })
        //ログイン権限がない場合はここでエラーのアラート
        .catch(error=>{
                alert('EmailまたはPasswordが間違っています。',error.message);
        })
    },
      //新規登録処理
      createUserSignIn(){
      //ファイアベースに情報を登録処理
         auth
        .createUserWithEmailAndPassword(this.signInEmail,this.signInPassword)
        .then(()=>{
          this.uid = auth.currentUser.uid
        })
        .then(()=>{
          const userData = {
              name:this.signInName,
              email:this.signInEmail,
              password:this.signInPassword,
            }
       const userCl = db.collection('users').doc(this.uid)
       userCl.set(userData)
            alert('登録が完了しました。');
            this.signinModalt = false
            this.$router.push('/');
        })
        //不備があった場合のエラー
        .catch(error =>{
            alert('エラー！',error.message);
            console.error('アカウント再登録エラー',error.message);
        })
    }
  }
  
}
</script>
<style>
.view{
  margin-top:50px;
}
