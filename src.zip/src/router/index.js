import Vue from 'vue'
import VueRouter from 'vue-router'
import NotFound from '../components/Not'
import Home from '../components/Home'
import Post from '../components/Post'
import Mypage from '../components/Mypage'
import Imageup from '../components/Imageup'
import {fb} from '../firebase'

Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name:'Home',
    component: Home,
    props:true,
  },
  {
    path: '/post',
    name: 'Post',
    component: Post,
    meta:{requiresAuth:true}
  },
  {
    path: '/mypage',
    name:'Mypage',
    component: Mypage,
    meta:{requiresAuth:true}
  },
  {
    path:'/imageup/:post',
    name:'Imageup',
    component: Imageup,
    mata:{requiresAuth:true},
  },
  {
    path:'*',
    component:NotFound
  }
  ]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
});

router.beforeEach(async (to, from, next) => {
  const requiresAuth = to.matched.some(recode => recode.meta.requiresAuth);
  if (requiresAuth && !(await fb.getCurrentUser())) {
    alert('ログインが確認できません')
    next({ path: "/", query: { redirect: to.fullPath } });
  } else {
    next();
  }
});


export default router
