import Vue from 'vue'
import Vuex from 'vuex'
import {auth,db,fb } from '../firebase'



Vue.use(Vuex)

export default new Vuex.Store({
  //strict:true,

  state: {
    //ui保管
    userUid:{
      uid:'',
    },
    user:{
      name:'',
      email:'',
      password:''
  },
    //user情報オブジェクト保管
      
    //user状態の表示  
    login:false,
    
  },
  getters:{
    uid: state =>{
      return state.userUid.uid
    },
    user: state =>{
      return state.user
    }
  },
 actions:{
   //ログイン保持
   autoLogin({commit}){
    auth.onAuthStateChanged(function (user) {
      if (user) {
        //リロードの際のuidの維持
        commit('setUid',{uid:user.uid})
        //リロードの際の再ログイン状態の確認。
        commit('switchLogin')
         
        //firestoreのユーザー情報をstateに保持
        const userRef = db.collection('users').doc(user.uid)
          userRef.get().then((doc)=>{
            if(doc.exists){
              const userData = doc.data()
                return commit('setUser',{name:userData.name, email:userData.email, password:userData.password})
            }
          })
      }
    })
   },
    //ログイン時の処理
  login({ commit }, payload) {
      auth.signInWithEmailAndPassword(payload.email, payload.password)
        .then(user => {
          console.log(user)
            auth.onAuthStateChanged(function (user) {
              if (user) {
                //ログイン時のuidの取得
                commit('setUid',{uid:user.uid})
                // ユーザー状態の切替
                commit('switchLogin')

                //firestoreのユーザー情報をstateへ渡す。
                const userRef = db.collection('users').doc(user.uid)
                  userRef.get().then((doc)=>{
                    if(doc.exists){
                      const userData = doc.data()
                      return commit('setUser',{name:userData.name, email:userData.email, password:userData.password})
                    }
                  })
              }
            })
         }).catch((error) => {
            alert(error)
          })
    },
    logOut({commit}){
      return commit('logOutSwitch')
    },
    //いいねボタンの追加処理
    addLike({getters},postId){
      const addRef = db.collection('posts').doc(postId)
            addRef.update({likeCount:fb.firestore.FieldValue.increment(1)})
              addRef.collection('like').doc(getters.uid)
                .set({
                  uid:getters.uid,
                  time:new Date
                })
    },
    //いいねボタンの削除処理
    deleteLike({getters},postId){
      const deleteRef = db.collection('posts').doc(postId)
            deleteRef.update({likeCount:fb.firestore.FieldValue.increment(-1)})
              deleteRef.collection('like').doc(getters.uid).delete()
    }
  },
  mutations: {
    setUid(state,payload){
      state.userUid.uid = payload.uid
    },
    switchLogin(state){
      state.login = true
    },
    logOutSwitch(state){
      state.login = false
    },
    setUser(state,payload){
      state.user.name = payload.name
      state.user.email = payload.email
      state.user.password = payload.password
    }
    
  },
  modules: {
  }
})
