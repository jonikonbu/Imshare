import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './plugins/element.js'
import firebase from './firebase'


firebase.init()
//firebase.onAuth()

//Bootstrap vue インポート
/*import {BootstrapVue,BootstrapVueIcons} from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
Vue.use(BootstrapVue)
Vue.use(BootstrapVueIcons)*/

/*import { library } from '@fortawesome/fontawesome-svg-core'
import { fas } from '@fortawesome/free-solid-svg-icons'
import { far } from '@fortawesome/free-regular-svg-icons'
import { fab } from '@fortawesome/free-brands-svg-icons'

//apple-alt アイコンをimport
//import { faAppleAlt } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'*/

import vuetify from './plugins/vuetify';
//利用するアイコンを設定

/*library.add(fas,far,fab)

Vue.component('font-awesome', FontAwesomeIcon)*/


Vue.config.productionTip = false


new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')

